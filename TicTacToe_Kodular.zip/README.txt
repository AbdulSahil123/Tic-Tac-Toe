Tic-Tac-Toe Game for Kodular

1. Open Kodular (https://creator.kodular.io/)
2. Create a new project named 'TicTacToe'
3. Use 9 buttons for the game grid
4. Add logic using Blocks (If you need help, check tutorials)
5. Enjoy your game!